# Normalized CSV schema

All files: UTF-8 CSV with a header row. Column names are case-insensitive. Numbers may contain commas or currency symbols. Aggregate duplicates are fine; the script sums them.

Common column: `period` = `current` (reporting month) or `previous` (comparison month).

| File | Columns | Notes |
|---|---|---|
| `account.csv` | period, impressions, clicks, conversions, cost | Account totals per month. If missing, totals are summed from campaigns.csv. |
| `campaigns.csv` | period, campaign, impressions, clicks, conversions, cost | Include all campaigns for both months. The script keeps only those with delivery in the current month. |
| `search_terms.csv` | period, search_term, impressions, clicks, conversions, cost | Export the full search terms report. Brand terms are removed by the script using `--brand-terms`. |
| `age.csv` | period, age_range, impressions, clicks, conversions, cost | Age ranges like `18-24`, `25-34`, `35-44`, `45-54`, `55-64`, `65+`, `Undetermined`. |
| `location.csv` | period, location, impressions, clicks, conversions, cost | Use the user-location report. Locations may be place names or pincodes. |
| `location_map.csv` | raw, place | Maps each pincode (or raw geo name) to a place name such as Chennai or Chengalpattu. |

## Mapping Google Ads export columns

| Google Ads column | Normalized |
|---|---|
| Impr. / Impressions | impressions |
| Clicks | clicks |
| Conversions | conversions |
| Cost | cost |
| Campaign | campaign |
| Search term | search_term |
| Age | age_range |
| Most specific location / Postal code / Location | location |

Skip the totals rows and the report title rows that Google Ads adds at the top and bottom of exports. Do not include CTR, CPC or cost per conversion columns; they are recomputed.
