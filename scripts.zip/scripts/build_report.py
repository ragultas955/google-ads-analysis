#!/usr/bin/env python3
"""
Google Ads monthly performance report builder (deterministic).

Builds the same 8-slide dashboard PPTX from normalized CSV files, so the layout,
numbers, charts and default insights are identical on any AI agent or machine
(ChatGPT, Codex, Claude, Claude Code, Gemini CLI, or plain terminal).

Usage:
  python build_report.py --data-dir ./data --client "Acme" \
      --month "August 2026" --prev-month "July 2026" \
      --brand-terms "acme,acme retail" --competitors "rival one,rival two" \
      --currency "Rs " --out Acme_Google_Ads_Aug_2026.pptx

Requires: python-pptx  (pip install python-pptx)
"""
import argparse
import csv
import json
import os
import re
import sys
from collections import defaultdict

from lxml import etree
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_AXIS_CROSSES, XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Inches, Pt

# ------------------------------------------------------------------ theme
FONT = "Arial"
NAVY = RGBColor(0x0B, 0x1F, 0x3A)
BLUE = RGBColor(0x1A, 0x73, 0xE8)
ORANGE = RGBColor(0xF9, 0xAB, 0x00)
GREEN = RGBColor(0x18, 0x80, 0x38)
RED = RGBColor(0xD9, 0x30, 0x25)
GRAY = RGBColor(0x5F, 0x63, 0x68)
LIGHT = RGBColor(0xF1, 0xF3, 0xF4)
LINE = RGBColor(0xDA, 0xDC, 0xE0)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
DARK = RGBColor(0x20, 0x21, 0x24)
PALETTE = [BLUE, ORANGE, GREEN, RGBColor(0x9B, 0x5D, 0xE5), RGBColor(0x00, 0xA8, 0xA8),
           RED, RGBColor(0x7F, 0x8C, 0x8D), RGBColor(0xE9, 0x1E, 0x63)]

NUM = ["impressions", "clicks", "conversions", "cost"]
AGE_ORDER = ["18-24", "25-34", "35-44", "45-54", "55-64", "65+", "undetermined"]


class Ctx:
    client = ""
    cur = "Current"
    prev = "Previous"
    sym = ""
    warnings = []
    overrides = {}


C = Ctx()


# ------------------------------------------------------------------ data helpers
def num(x):
    if x is None:
        return 0.0
    s = re.sub(r"[^0-9.\-]", "", str(x).replace(",", ""))
    if s in ("", "-", ".", "-."):
        return 0.0
    try:
        v = float(s)
    except ValueError:
        return 0.0
    # Google exports show CTR as "5.2%" etc; we never read CTR, only raw counts
    return v


def load(path):
    if not os.path.exists(path):
        return None
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    out = []
    for r in rows:
        out.append({(k or "").strip().lower().replace(" ", "_"): v for k, v in r.items()})
    return out


def zero():
    return dict.fromkeys(NUM, 0.0)


def aggregate(rows, key, transform=None):
    """-> {'current': {name: metrics}, 'previous': {...}}"""
    out = {"current": defaultdict(zero), "previous": defaultdict(zero)}
    for r in rows or []:
        p = (r.get("period") or "").strip().lower()
        if p not in out:
            continue
        k = (r.get(key) or "").strip()
        if transform:
            k = transform(k)
        if not k:
            continue
        for m in NUM:
            out[p][k][m] += num(r.get(m))
    return out


def derive(m):
    m = dict(m)
    m["ctr"] = m["clicks"] / m["impressions"] if m["impressions"] else 0.0
    m["cpc"] = m["cost"] / m["clicks"] if m["clicks"] else 0.0
    m["cpa"] = m["cost"] / m["conversions"] if m["conversions"] else 0.0
    return m


def sumdicts(dicts):
    t = zero()
    for d in dicts:
        for m in NUM:
            t[m] += d[m]
    return t


def delta(cur, prev):
    if prev is None or prev == 0:
        return None
    return (cur - prev) / prev


def fmt_delta(d, lower_better=False):
    if d is None:
        return "New", GRAY
    if abs(d) < 0.0005:
        return "0.0%", GRAY
    arrow = "\u25B2" if d > 0 else "\u25BC"
    good = d < 0 if lower_better else d > 0
    return f"{arrow} {abs(d) * 100:.1f}%", (GREEN if good else RED)


def money(v):
    return f"{C.sym}{v:,.0f}" if abs(v) >= 100 else f"{C.sym}{v:,.2f}"


def n0(v):
    return f"{v:,.0f}"


def n1(v):
    return f"{v:,.1f}"


def pct(v):
    return f"{v * 100:.2f}%"


def trunc(s, n):
    return s if len(s) <= n else s[: n - 1] + "\u2026"


def rank_key(m):
    return (-m["clicks"], -m["conversions"], -m["impressions"])


# ------------------------------------------------------------------ insight engine (rule based, deterministic)
def row_insight(cur, prev, avg_cpa):
    if prev is None or (prev["impressions"] == 0 and prev["clicks"] == 0 and prev["cost"] == 0):
        return f"New vs {C.prev}"
    parts = []
    dc = delta(cur["conversions"], prev["conversions"])
    if dc is not None and dc >= 0.10:
        parts.append(f"Conversions up {dc * 100:.0f}%")
    elif dc is not None and dc <= -0.10:
        parts.append(f"Conversions down {abs(dc) * 100:.0f}%")
    elif prev["conversions"] == 0 and cur["conversions"] > 0:
        parts.append("First conversions")
    if cur["conversions"] > 0 and avg_cpa:
        if cur["cpa"] <= 0.8 * avg_cpa:
            parts.append("Efficient CPA")
        elif cur["cpa"] >= 1.25 * avg_cpa:
            parts.append("High CPA, optimise")
    elif cur["conversions"] == 0 and cur["cost"] > 0:
        parts.append("No conversions, review")
    dcp = delta(cur["cpc"], prev["cpc"])
    if len(parts) < 2 and dcp is not None and dcp >= 0.15:
        parts.append(f"CPC up {dcp * 100:.0f}%")
    elif len(parts) < 2 and dcp is not None and dcp <= -0.15:
        parts.append(f"CPC down {abs(dcp) * 100:.0f}%")
    return "; ".join(parts[:2]) or "Stable"


def key_insights(label, names, cur, prev, section):
    ov = C.overrides.get("bullets", {}).get(section)
    if ov:
        return ov[:4]
    tot = derive(sumdicts([cur[n] for n in names]))
    if not names or tot["clicks"] == 0:
        return ["No data available for this section."] * 1
    top_clk = max(names, key=lambda n: (cur[n]["clicks"], cur[n]["conversions"]))
    top_cv = max(names, key=lambda n: (cur[n]["conversions"], cur[n]["clicks"]))
    b = []
    s = cur[top_clk]
    b.append(f"{top_clk} leads on traffic with {n0(s['clicks'])} clicks "
             f"({s['clicks'] / tot['clicks'] * 100:.0f}% of total) from {n0(s['impressions'])} impressions.")
    if tot["conversions"] > 0:
        s = cur[top_cv]
        avg = tot["cpa"]
        b.append(f"{top_cv} drives the most conversions ({n1(s['conversions'])}, "
                 f"{s['conversions'] / tot['conversions'] * 100:.0f}% of total) at {money(s['cpa'])} per conversion "
                 f"vs {money(avg)} average for this view.")
    else:
        b.append(f"No conversions were recorded across the {label} shown; review tracking and targeting.")
    gains = []
    for n in names:
        p = prev.get(n)
        gains.append((cur[n]["conversions"] - (p["conversions"] if p else 0.0), n))
    if prev:
        best = max(gains)
        worst = min(gains)
        if best[0] > 0:
            p = prev.get(best[1])
            b.append(f"{best[1]} gained the most vs {C.prev}: conversions {n1(p['conversions'] if p else 0)} to "
                     f"{n1(cur[best[1]]['conversions'])} (+{n1(best[0])}).")
        elif worst[0] < 0:
            p = prev.get(worst[1])
            b.append(f"No {label} grew conversions vs {C.prev}; {worst[1]} fell most "
                     f"({n1(p['conversions'])} to {n1(cur[worst[1]]['conversions'])}).")
        else:
            b.append(f"Conversions held flat vs {C.prev} across the {label} shown.")
    else:
        b.append(f"No {C.prev} data available for comparison.")
    # concern: material spend with weak efficiency
    concern = None
    for n in sorted(names, key=lambda n: -cur[n]["cost"]):
        c = cur[n]
        if tot["cost"] and c["cost"] / tot["cost"] >= 0.05:
            if c["conversions"] == 0:
                concern = f"{n} used {c['cost'] / tot['cost'] * 100:.0f}% of spend ({money(c['cost'])}) with no conversions; tighten targeting or bids."
                break
            if tot["cpa"] and c["cpa"] >= 1.25 * tot["cpa"]:
                concern = (f"{n} costs {money(c['cpa'])} per conversion, "
                           f"{(c['cpa'] / tot['cpa'] - 1) * 100:.0f}% above average; optimise bids or budget share.")
                break
    b.append(concern or f"Spend is balanced: no major {label} item runs materially above average cost per conversion.")
    return b


# ------------------------------------------------------------------ pptx helpers
def new_prs():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    return prs


def textbox(slide, x, y, w, h, text, size=12, bold=False, color=DARK, align=PP_ALIGN.LEFT,
            anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(0.05)
    tf.margin_top = tf.margin_bottom = Inches(0.02)
    p = tf.paragraphs[0]
    p.alignment = align
    r = p.add_run()
    r.text = text
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.name = FONT
    r.font.color.rgb = color
    return tb


def rect(slide, x, y, w, h, fill, line=None, shape=MSO_SHAPE.RECTANGLE):
    s = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    s.fill.solid()
    s.fill.fore_color.rgb = fill
    if line is None:
        s.line.fill.background()
    else:
        s.line.color.rgb = line
        s.line.width = Pt(0.75)
    s.shadow.inherit = False
    return s


def base_slide(prs, title, subtitle, idx):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    rect(slide, 0, 0, 13.333, 1.0, NAVY)
    rect(slide, 0, 1.0, 13.333, 0.05, BLUE)
    textbox(slide, 0.4, 0.12, 8.6, 0.5, title, 24, True, WHITE, anchor=MSO_ANCHOR.MIDDLE)
    textbox(slide, 0.4, 0.60, 8.6, 0.3, subtitle, 12, False, RGBColor(0xBD, 0xC1, 0xC6))
    textbox(slide, 8.9, 0.25, 4.0, 0.5, f"{C.cur}  vs  {C.prev}", 14, True, WHITE, PP_ALIGN.RIGHT,
            MSO_ANCHOR.MIDDLE)
    textbox(slide, 0.4, 7.12, 10, 0.3, f"{C.client} | Google Ads | Source: Google Ads data export",
            9, False, GRAY)
    textbox(slide, 12.0, 7.12, 0.95, 0.3, str(idx), 9, False, GRAY, PP_ALIGN.RIGHT)
    return slide


def insights_panel(slide, x, y, w, h, bullets):
    rect(slide, x, y, w, h, LIGHT, LINE, MSO_SHAPE.ROUNDED_RECTANGLE).adjustments[0] = 0.06
    rect(slide, x, y + 0.1, 0.07, h - 0.2, BLUE)
    textbox(slide, x + 0.2, y + 0.05, w - 0.4, 0.32, "Key Insights", 13, True, NAVY)
    tb = slide.shapes.add_textbox(Inches(x + 0.2), Inches(y + 0.38), Inches(w - 0.4), Inches(h - 0.45))
    tf = tb.text_frame
    tf.word_wrap = True
    for i, t in enumerate(bullets[:4]):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.space_after = Pt(3)
        r = p.add_run()
        r.text = "\u2022  " + t
        r.font.size = Pt(11)
        r.font.name = FONT
        r.font.color.rgb = DARK


def chart_title(slide, x, y, w, text):
    textbox(slide, x, y, w, 0.3, text, 12, True, NAVY)


def style_axis_text(ch, size=9):
    ch.category_axis.tick_labels.font.size = Pt(size)
    ch.category_axis.tick_labels.font.name = FONT
    ch.value_axis.tick_labels.font.size = Pt(8)
    ch.value_axis.tick_labels.font.name = FONT


def bar_chart(slide, x, y, w, h, cats, series, log=False):
    cd = CategoryChartData()
    cd.categories = [trunc(c, 30) for c in cats]
    for name, vals in series:
        cd.add_series(name, [float(v) for v in vals])
    gf = slide.shapes.add_chart(XL_CHART_TYPE.BAR_CLUSTERED, Inches(x), Inches(y), Inches(w), Inches(h), cd)
    ch = gf.chart
    ch.font.name = FONT
    ch.has_title = False
    ch.has_legend = len(series) > 1
    if ch.has_legend:
        ch.legend.position = XL_LEGEND_POSITION.BOTTOM
        ch.legend.include_in_layout = False
        ch.legend.font.size = Pt(9)
    style_axis_text(ch)
    ch.category_axis.reverse_order = True
    ch.category_axis.crosses = XL_AXIS_CROSSES.MAXIMUM
    ch.value_axis.has_major_gridlines = True
    ch.value_axis.major_gridlines.format.line.color.rgb = LINE
    ch.value_axis.format.line.fill.background()
    plot = ch.plots[0]
    plot.gap_width = 55
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.font.size = Pt(8)
    dl.font.name = FONT
    dl.number_format = "#,##0.#"
    dl.number_format_is_linked = False
    dl.position = XL_LABEL_POSITION.OUTSIDE_END
    for i, s in enumerate(plot.series):
        s.format.fill.solid()
        s.format.fill.fore_color.rgb = PALETTE[i % len(PALETTE)]
    if log:
        ch.value_axis.minimum_scale = 1
        scaling = ch.value_axis._element.find(qn("c:scaling"))
        lb = etree.SubElement(scaling, qn("c:logBase"))
        lb.set("val", "10")
        scaling.remove(lb)
        scaling.insert(0, lb)
    return ch


def pie_chart(slide, x, y, w, h, cats, vals):
    cd = CategoryChartData()
    cd.categories = list(cats)
    cd.add_series("Share", [float(v) for v in vals])
    gf = slide.shapes.add_chart(XL_CHART_TYPE.PIE, Inches(x), Inches(y), Inches(w), Inches(h), cd)
    ch = gf.chart
    ch.font.name = FONT
    ch.has_title = False
    ch.has_legend = True
    ch.legend.position = XL_LEGEND_POSITION.RIGHT
    ch.legend.include_in_layout = False
    ch.legend.font.size = Pt(10)
    plot = ch.plots[0]
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.show_percentage = True
    dl.show_value = False
    dl.show_category_name = False
    dl.number_format = "0.0%"
    dl.number_format_is_linked = False
    dl.font.size = Pt(10)
    dl.font.bold = True
    dl.font.color.rgb = WHITE
    dl.position = XL_LABEL_POSITION.CENTER
    for i, pt in enumerate(plot.series[0].points):
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = PALETTE[i % len(PALETTE)]
    return ch


def table(slide, x, y, cols, rows, font=9, row_h=0.26, header_h=0.32, total_row=False):
    """cols: [(header, width_in, align)] ; rows: list of list of str | (str, RGBColor)"""
    w = sum(c[1] for c in cols)
    shape = slide.shapes.add_table(len(rows) + 1, len(cols), Inches(x), Inches(y), Inches(w),
                                   Inches(header_h + row_h * len(rows)))
    tbl = shape.table
    tblPr = shape._element.graphic.graphicData.tbl.tblPr
    tblPr.set("bandRow", "0")
    tblPr.set("firstRow", "0")
    for i, c in enumerate(cols):
        tbl.columns[i].width = Inches(c[1])
    tbl.rows[0].height = Inches(header_h)
    for r in range(1, len(rows) + 1):
        tbl.rows[r].height = Inches(row_h)

    def put(cell, text, color, bold, fill, align):
        cell.fill.solid()
        cell.fill.fore_color.rgb = fill
        cell.margin_left = cell.margin_right = Inches(0.05)
        cell.margin_top = cell.margin_bottom = Inches(0.01)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = align
        run = p.add_run()
        run.text = text
        run.font.size = Pt(font)
        run.font.bold = bold
        run.font.name = FONT
        run.font.color.rgb = color

    al = {"l": PP_ALIGN.LEFT, "r": PP_ALIGN.RIGHT, "c": PP_ALIGN.CENTER}
    for i, c in enumerate(cols):
        put(tbl.cell(0, i), c[0], WHITE, True, NAVY, al[c[2]] if c[2] != "r" else PP_ALIGN.RIGHT)
    for r, row in enumerate(rows, start=1):
        last = total_row and r == len(rows)
        fill = RGBColor(0xE8, 0xF0, 0xFE) if last else (LIGHT if r % 2 == 0 else WHITE)
        for i, cell in enumerate(row):
            text, color = (cell if isinstance(cell, tuple) else (cell, DARK))
            put(tbl.cell(r, i), text, color, last or (isinstance(cell, tuple) and color in (GREEN, RED)),
                fill, al[cols[i][2]])
    return tbl


def dim_prep(agg, order=None):
    cur = {k: derive(v) for k, v in agg["current"].items()
           if v["impressions"] > 0 or v["cost"] > 0 or v["clicks"] > 0}
    prev = {k: derive(v) for k, v in agg["previous"].items()}
    names = sorted(cur, key=lambda n: rank_key(cur[n]))
    if order:
        names = sorted(cur, key=lambda n: order.index(n.lower()) if n.lower() in order else 99)
    return names, cur, prev


def dim_table(slide, x, y, section, name_header, names, cur, prev, avg_cpa, top_n,
              competitors=None, rank=False, row_h=0.26, font=9, with_others=False):
    show = names[:top_n]
    rest = names[top_n:]
    cols = []
    if rank:
        cols.append(("#", 0.4, "c"))
    fixed = [("Impr.", 0.9, "r"), ("Clicks", 0.8, "r"), ("CTR", 0.7, "r"), ("Conv.", 0.7, "r"),
             ("Cost", 0.95, "r"), ("Cost/Conv.", 0.9, "r"), ("Clicks \u0394", 0.85, "r"),
             ("Conv. \u0394", 0.85, "r"), ("Insight", 2.6, "l")]
    type_w = 0.95 if competitors else 0
    used = sum(c[1] for c in cols) + sum(c[1] for c in fixed) + type_w
    cols.append((name_header, 12.45 - used, "l"))
    if competitors:
        cols.append(("Type", type_w, "c"))
    cols += fixed
    rows = []
    ov = C.overrides.get(section, {})
    for i, n in enumerate(show, 1):
        c, p = cur[n], prev.get(n)
        dcl, colc = fmt_delta(delta(c["clicks"], p["clicks"]) if p else None)
        dcv, colv = fmt_delta(delta(c["conversions"], p["conversions"]) if p else None)
        row = []
        if rank:
            row.append(str(i))
        row.append(trunc(n, 48))
        if competitors:
            row.append("Competitor" if n.lower() in competitors else "Generic")
        row += [n0(c["impressions"]), n0(c["clicks"]), pct(c["ctr"]), n1(c["conversions"]), money(c["cost"]),
                money(c["cpa"]) if c["conversions"] else "-", (dcl, colc), (dcv, colv),
                trunc(ov.get(n) or row_insight(c, p, avg_cpa), 46)]
        rows.append(row)
    if with_others and rest:
        o = derive(sumdicts([cur[n] for n in rest]))
        po = sumdicts([prev[n] for n in rest if n in prev]) if prev else None
        po = derive(po) if po else None
        dcl, colc = fmt_delta(delta(o["clicks"], po["clicks"]) if po else None)
        dcv, colv = fmt_delta(delta(o["conversions"], po["conversions"]) if po else None)
        row = ([""] if rank else []) + [f"Others ({len(rest)})"]
        row += [n0(o["impressions"]), n0(o["clicks"]), pct(o["ctr"]), n1(o["conversions"]), money(o["cost"]),
                money(o["cpa"]) if o["conversions"] else "-", (dcl, colc), (dcv, colv),
                trunc(row_insight(o, po, avg_cpa), 46)]
        rows.append(row)
    table(slide, x, y, cols, rows, font=font, row_h=row_h)


# ------------------------------------------------------------------ main build
def main():
    ap = argparse.ArgumentParser(description="Build the Google Ads monthly 8-slide PPT report.")
    ap.add_argument("--data-dir", required=True, help="folder with normalized CSVs (see references/data-schema.md)")
    ap.add_argument("--client", required=True)
    ap.add_argument("--month", required=True, help='reporting month label, e.g. "August 2026"')
    ap.add_argument("--prev-month", required=True, help='comparison month label, e.g. "July 2026"')
    ap.add_argument("--brand-terms", default="", help="comma separated brand terms to exclude from search terms")
    ap.add_argument("--competitors", default="", help="comma separated competitor terms (used to tag the Type column)")
    ap.add_argument("--currency", default="", help='currency prefix, e.g. "Rs " or "$"')
    ap.add_argument("--insights", default="", help="optional insights.json overriding auto-generated insight text")
    ap.add_argument("--top-terms", type=int, default=20)
    ap.add_argument("--top-locations", type=int, default=15)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    C.client, C.cur, C.prev, C.sym = a.client, a.month, a.prev_month, a.currency
    if a.insights and os.path.exists(a.insights):
        with open(a.insights, encoding="utf-8") as f:
            C.overrides = json.load(f)
    d = a.data_dir
    campaigns = load(os.path.join(d, "campaigns.csv"))
    terms = load(os.path.join(d, "search_terms.csv"))
    age = load(os.path.join(d, "age.csv"))
    loc = load(os.path.join(d, "location.csv"))
    account = load(os.path.join(d, "account.csv"))
    locmap_rows = load(os.path.join(d, "location_map.csv")) or []
    locmap = {(r.get("raw") or "").strip().lower(): (r.get("place") or "").strip() for r in locmap_rows}
    if campaigns is None and account is None:
        sys.exit("ERROR: need at least campaigns.csv or account.csv in --data-dir")

    brand = [b.strip().lower() for b in a.brand_terms.split(",") if b.strip()]
    brand_nospace = [re.sub(r"\s+", "", b) for b in brand]
    competitors = {c.strip().lower() for c in a.competitors.split(",") if c.strip()}

    def is_brand(t):
        tl = t.lower()
        tn = re.sub(r"\s+", "", tl)
        return any(b in tl for b in brand) or any(b in tn for b in brand_nospace)

    # ---- account totals
    camp_agg = aggregate(campaigns, "campaign") if campaigns else None
    if account:
        acc = {p: zero() for p in ("current", "previous")}
        for r in account:
            p = (r.get("period") or "").strip().lower()
            if p in acc:
                for m in NUM:
                    acc[p][m] += num(r.get(m))
    else:
        acc = {p: sumdicts(camp_agg[p].values()) for p in ("current", "previous")}
        C.warnings.append("account.csv not found; totals were summed from campaigns.csv")
    if account and camp_agg:
        for p in ("current", "previous"):
            cs = sumdicts(camp_agg[p].values())
            for m in ("clicks", "cost"):
                if acc[p][m] and abs(cs[m] - acc[p][m]) / acc[p][m] > 0.01:
                    C.warnings.append(f"{p} {m}: campaign sum {cs[m]:,.0f} differs from account total "
                                      f"{acc[p][m]:,.0f} by >1% (paused/removed campaigns?)")
    A, P = derive(acc["current"]), derive(acc["previous"])
    avg_cpa = A["cpa"]

    prs = new_prs()
    sub = f"{C.client} | Google Ads performance dashboard"

    # ---- slide 1: overall
    s = base_slide(prs, "Overall Performance", sub, 1)
    kpis = [("Impressions", A["impressions"], P["impressions"], n0, False),
            ("Clicks", A["clicks"], P["clicks"], n0, False),
            ("Conversions", A["conversions"], P["conversions"], n1, False),
            ("Cost", A["cost"], P["cost"], money, True),
            ("Avg. CPC", A["cpc"], P["cpc"], money, True),
            ("CTR", A["ctr"], P["ctr"], pct, False)]
    cw, ch_, gx, gy, x0, y0 = 4.0, 2.05, 0.2, 0.25, 0.4, 1.4
    for i, (lab, cv, pv, f, lower) in enumerate(kpis):
        cx = x0 + (i % 3) * (cw + gx)
        cy = y0 + (i // 3) * (ch_ + gy)
        rect(s, cx, cy, cw, ch_, WHITE, LINE, MSO_SHAPE.ROUNDED_RECTANGLE).adjustments[0] = 0.05
        rect(s, cx, cy + 0.15, 0.07, ch_ - 0.3, BLUE)
        textbox(s, cx + 0.25, cy + 0.12, cw - 0.4, 0.35, lab, 13, True, GRAY)
        textbox(s, cx + 0.25, cy + 0.5, cw - 0.4, 0.7, f(cv), 32, True, NAVY)
        dt, dc = fmt_delta(delta(cv, pv), lower)
        textbox(s, cx + 0.25, cy + 1.3, 1.6, 0.35, dt, 15, True, dc)
        textbox(s, cx + 1.75, cy + 1.33, cw - 1.9, 0.35, f"{C.prev}: {f(pv)}", 11, False, GRAY, PP_ALIGN.RIGHT)
    parts = []
    for lab, cv, pv, lower in (("clicks", A["clicks"], P["clicks"], False),
                               ("conversions", A["conversions"], P["conversions"], False),
                               ("cost per conversion", A["cpa"], P["cpa"], True)):
        dd = delta(cv, pv)
        if dd is None:
            parts.append(f"{lab} new")
        else:
            parts.append(f"{lab} {'up' if dd > 0 else 'down'} {abs(dd) * 100:.1f}%")
    headline = C.overrides.get("headline") or f"{C.cur} vs {C.prev}: " + ", ".join(parts) + "."
    rect(s, 0.4, 6.2, 12.5, 0.7, LIGHT, LINE, MSO_SHAPE.ROUNDED_RECTANGLE).adjustments[0] = 0.15
    textbox(s, 0.6, 6.2, 12.1, 0.7, headline, 14, True, NAVY, anchor=MSO_ANCHOR.MIDDLE)

    # ---- slide 2: campaigns
    s = base_slide(prs, "Campaign Performance", f"Campaigns that ran in {C.cur}", 2)
    if camp_agg:
        names, cur, prev = dim_prep(camp_agg)
        names = [n for n in names]
        show = names[:12]
        cols = [("Campaign", 3.05, "l"), ("Impr.", 0.9, "r"), ("Clicks", 0.8, "r"), ("CTR", 0.7, "r"),
                ("Avg. CPC", 0.8, "r"), ("Conv.", 0.7, "r"), ("Cost", 0.95, "r"), ("Cost/Conv.", 0.9, "r"),
                ("Conv. \u0394", 0.85, "r"), ("Insight", 2.8, "l")]
        rows = []
        for n in show:
            c, p = cur[n], prev.get(n)
            dcv, colv = fmt_delta(delta(c["conversions"], p["conversions"]) if p else None)
            ins = C.overrides.get("campaigns", {}).get(n) or row_insight(c, p, avg_cpa)
            rows.append([trunc(n, 44), n0(c["impressions"]), n0(c["clicks"]), pct(c["ctr"]), money(c["cpc"]),
                         n1(c["conversions"]), money(c["cost"]), money(c["cpa"]) if c["conversions"] else "-",
                         (dcv, colv), trunc(ins, 50)])
        t = derive(sumdicts([cur[n] for n in names]))
        tp = derive(sumdicts([prev[n] for n in names if n in prev])) if prev else None
        dcv, colv = fmt_delta(delta(t["conversions"], tp["conversions"]) if tp else None)
        rows.append([f"Total ({len(names)} campaigns)", n0(t["impressions"]), n0(t["clicks"]), pct(t["ctr"]),
                     money(t["cpc"]), n1(t["conversions"]), money(t["cost"]),
                     money(t["cpa"]) if t["conversions"] else "-", (dcv, colv), ""])
        table(s, 0.4, 1.35, cols, rows, font=10, row_h=0.34, total_row=True)
        if len(names) > 12:
            C.warnings.append(f"campaign table shows top 12 of {len(names)} by clicks; total row covers all")
    else:
        textbox(s, 0.4, 2, 12, 1, "campaigns.csv not provided", 16, False, GRAY)

    # ---- search terms
    st_agg = None
    if terms:
        st_agg = aggregate(terms, "search_term")
        for p in ("current", "previous"):
            for k in [k for k in st_agg[p] if is_brand(k)]:
                del st_agg[p][k]
        names, cur, prev = dim_prep(st_agg)
        top10 = names[:10]
        s = base_slide(prs, "Search Term Analysis", f"Top search terms in {C.cur} (brand terms excluded, competitors kept)", 3)
        chart_title(s, 0.4, 1.12, 6.1, "Search terms vs impressions & clicks (log scale)")
        bar_chart(s, 0.3, 1.4, 6.3, 3.6, top10, [("Impressions", [cur[n]["impressions"] for n in top10]),
                                                   ("Clicks", [cur[n]["clicks"] for n in top10])], log=True)
        chart_title(s, 6.8, 1.12, 6.1, "Search terms vs conversions")
        bar_chart(s, 6.7, 1.4, 6.3, 3.6, top10, [(C.cur, [cur[n]["conversions"] for n in top10]),
                                                   (C.prev, [prev[n]["conversions"] if n in prev else 0 for n in top10])])
        insights_panel(s, 0.4, 5.1, 12.5, 1.95, key_insights("search terms", top10, cur, prev, "search_terms"))

        s = base_slide(prs, f"Top {a.top_terms} Search Terms", f"Ranked by clicks in {C.cur}; brand terms excluded", 4)
        dim_table(s, 0.4, 1.2, "search_terms", "Search term", names, cur, prev, avg_cpa, a.top_terms,
                  competitors=competitors, rank=True, row_h=0.245, font=9)
    else:
        for i, t in ((3, "Search Term Analysis"), (4, f"Top {a.top_terms} Search Terms")):
            s = base_slide(prs, t, "", i)
            textbox(s, 0.4, 2, 12, 1, "search_terms.csv not provided", 16, False, GRAY)

    # ---- age
    if age:
        ag = aggregate(age, "age_range", lambda k: re.sub(r"\s*[\u2013\u2014]\s*", "-", k.strip()))
        names, cur, prev = dim_prep(ag, AGE_ORDER)
        tc = sum(cur[n]["clicks"] for n in names) or 1
        pie_names = [n for n in names if not (n.lower() == "undetermined" and cur[n]["clicks"] / tc < 0.05)]
        s = base_slide(prs, "Age Group Analysis", f"Clicks and conversions by age group, {C.cur}", 5)
        chart_title(s, 0.4, 1.12, 6.1, "Clicks by age group")
        pie_chart(s, 0.3, 1.4, 6.3, 3.6, pie_names, [cur[n]["clicks"] for n in pie_names])
        chart_title(s, 6.8, 1.12, 6.1, "Conversions by age group")
        if sum(cur[n]["conversions"] for n in pie_names) > 0:
            pie_chart(s, 6.7, 1.4, 6.3, 3.6, pie_names, [cur[n]["conversions"] for n in pie_names])
        else:
            textbox(s, 6.8, 2.8, 6, 0.5, "No conversions recorded", 14, False, GRAY)
        insights_panel(s, 0.4, 5.1, 12.5, 1.95, key_insights("age groups", names, cur, prev, "age"))
        s = base_slide(prs, "Age Group Table", f"Age group performance, {C.cur} vs {C.prev}", 6)
        dim_table(s, 0.4, 1.4, "age", "Age group", names, cur, prev, avg_cpa, 10, row_h=0.45, font=11)
    else:
        for i, t in ((5, "Age Group Analysis"), (6, "Age Group Table")):
            s = base_slide(prs, t, "", i)
            textbox(s, 0.4, 2, 12, 1, "age.csv not provided", 16, False, GRAY)

    # ---- location
    if loc:
        def place(k):
            kl = k.strip().lower()
            if kl in locmap:
                return locmap[kl]
            if re.fullmatch(r"\d{5,6}", kl):
                C.warnings.append(f"unmapped pincode {k} grouped under Other; add it to location_map.csv")
                return "Other"
            return k.strip()

        lg = aggregate(loc, "location", place)
        names, cur, prev = dim_prep(lg)
        if "Other" in names:
            names = [n for n in names if n != "Other"] + ["Other"]
        top8 = [n for n in names if n != "Other"][:8]
        s = base_slide(prs, "Location Analysis", f"Top locations in {C.cur}", 7)
        chart_title(s, 0.4, 1.12, 6.1, "Location vs impressions & clicks (log scale)")
        bar_chart(s, 0.3, 1.4, 6.3, 3.6, top8, [("Impressions", [cur[n]["impressions"] for n in top8]),
                                                  ("Clicks", [cur[n]["clicks"] for n in top8])], log=True)
        chart_title(s, 6.8, 1.12, 6.1, "Location vs conversions")
        bar_chart(s, 6.7, 1.4, 6.3, 3.6, top8, [(C.cur, [cur[n]["conversions"] for n in top8]),
                                                  (C.prev, [prev[n]["conversions"] if n in prev else 0 for n in top8])])
        insights_panel(s, 0.4, 5.1, 12.5, 1.95, key_insights("locations", top8, cur, prev, "location"))
        s = base_slide(prs, "Location Performance Table", f"Top {a.top_locations} locations by clicks, {C.cur} vs {C.prev}", 8)
        dim_table(s, 0.4, 1.2, "location", "Location", names, cur, prev, avg_cpa, a.top_locations,
                  rank=True, row_h=0.3, font=10, with_others=True)
    else:
        for i, t in ((7, "Location Analysis"), (8, "Location Performance Table")):
            s = base_slide(prs, t, "", i)
            textbox(s, 0.4, 2, 12, 1, "location.csv not provided", 16, False, GRAY)

    prs.save(a.out)
    print(f"Saved {a.out} (8 slides)")
    for w in dict.fromkeys(C.warnings):
        print("WARNING:", w)


if __name__ == "__main__":
    main()
